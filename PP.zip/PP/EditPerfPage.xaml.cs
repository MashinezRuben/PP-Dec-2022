﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для AddInfPage.xaml
    /// </summary>
    public partial class EditPerfPage : Page
    {
        public StudPerf center = new StudPerf();
        private readonly StudPerf centerfield = new StudPerf();
        public EditPerfPage(StudPerf selectedCenter)
        {
            InitializeComponent();
            cmbGroup.SelectedValuePath = "id";
            cmbGroup.DisplayMemberPath = "Название";
            cmbGroup.ItemsSource = AppConnect.model.Group.ToList();
        //  cmbDisc.SelectedValuePath = "id";
         //   cmbDisc.DisplayMemberPath = "Наименование";
            cmbDisc.ItemsSource = AppConnect.model.Discipline.Select(x=>x.Наименование).Distinct().ToList();
            cmbFIO.ItemsSource=AppConnect.model.PersInf.Select(x=>x.ФИО).Distinct().ToList();
            if (selectedCenter != null)
            {
                centerfield = selectedCenter;
            }
            DataContext = centerfield;
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.GoBack();
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)
        {            
            try
            {                 
                StudPerf servObj = new StudPerf()
                {
                    id = Convert.ToInt32(tbID.Text),
                    Group = cmbGroup.SelectedItem as Group,
                    Учащийся = cmbFIO.SelectedIndex,
                   Discipline=cmbDisc.SelectedItem as Discipline,// <- бесстыдник
               //  Дисциплина=cmbDisc.SelectedIndex,
                    Оценка = Convert.ToInt32(tbOtz.Text),
                };             
                AppConnect.model.SaveChanges();
                AppFrame.frameMain.GoBack();
            }
            catch (DbEntityValidationException ex)
            {
                MessageBox.Show("Ошибка:" + ex.Message.ToString(), "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
/// мне хочеца плакатб
