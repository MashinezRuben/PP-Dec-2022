﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PP
{
    class AddEdit
    {
        public static int ID { get; set; }
    }
}
