﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для PersInform.xaml
    /// </summary>
    public partial class PersInform : Page
    {
        public PersInform()
        {
            InitializeComponent();
            InfGrid.ItemsSource = AppConnect.model.PersInf.ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.GoBack();
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            var cur = AppConnect.model.PersInf.ToList();

            cur = cur.Where(x => x.ФИО.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Group.Название.ToString().ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.АдресПроживания.ToLower().StartsWith(tbSearch.Text.ToLower()) |
            x.Образование.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.ДатаРождения.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Работа.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Должность.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Стаж.ToLower().StartsWith(tbSearch.Text.ToLower())
            ).ToList();

            InfGrid.ItemsSource = cur.ToList();
            
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddInfPage());
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            InfGrid.ItemsSource = AppConnect.model.PersInf.ToList();
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show($"Вы точно хотите удалить данные?", "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                if (InfGrid.SelectedItems.Count > 0)
                {
                    for (int i = 0; i < InfGrid.SelectedItems.Count; i++)
                    {
                        PersInf prodObj = InfGrid.SelectedItems[i] as PersInf;
                        AppConnect.model.PersInf.Remove(prodObj);
                    }
                    AppConnect.model.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Hет данных!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            InfGrid.ItemsSource = AppConnect.model.PersInf.ToList();
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new EditInfPage((sender as Button).DataContext as PersInf));
        }
    }
}
