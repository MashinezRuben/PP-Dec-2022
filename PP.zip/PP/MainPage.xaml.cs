﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>    
    public partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
            PerfGrid.ItemsSource = AppConnect.model.StudPerf.ToList();// вывод данных
            cmbGroup.ItemsSource = AppConnect.model.Group.Select(x => x.Название).Distinct().ToList();
            cmbDisc.ItemsSource = AppConnect.model.Discipline.Select(x => x.Наименование).Distinct().ToList();
        }

        private void tbSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            cmbGroup.SelectedIndex = -1;
            cmbDisc.SelectedIndex = -1;
            var cur = AppConnect.model.StudPerf.ToList();

            cur = cur.Where(x => x.PersInf.ФИО.ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Group.Название.ToString().ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Discipline.Наименование.ToString().ToLower().StartsWith(tbSearch.Text.ToLower()) ||
            x.Оценка.ToString().ToLower().StartsWith(tbSearch.Text.ToLower())
            ).ToList();
           
            PerfGrid.ItemsSource = cur.ToList();
        }

        private void btnInf_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new PersInform());
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.Navigate(new AddPerfPage());
        }

        private void btnEdit_Click(object sender, RoutedEventArgs e)
        {
           AppFrame.frameMain.Navigate(new EditPerfPage((sender as Button).DataContext as StudPerf));
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            PerfGrid.ItemsSource = AppConnect.model.StudPerf.ToList();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            cmbGroup.SelectedIndex =-1;
            cmbDisc.SelectedIndex = -1;
            PerfGrid.ItemsSource = AppConnect.model.StudPerf.ToList();
        }

        private void cmbGroup_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {           
            tbSearch.Text = "";
            if (cmbGroup.SelectedIndex >= 0)
            {
                cmbDisc.SelectedIndex = -1;               

                var cur = AppConnect.model.StudPerf.ToList();
                cur = cur.Where(x => x.PersInf.Group.Название.ToString().StartsWith(cmbGroup.SelectedItem.ToString())).ToList();
                PerfGrid.ItemsSource = cur.ToList();
            }
        }

        private void btnDel_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show($"Вы точно хотите удалить данные?", "Внимание!", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                if (PerfGrid.SelectedItems.Count > 0)
                {
                    for (int i = 0; i < PerfGrid.SelectedItems.Count; i++)
                    {
                        StudPerf prodObj = PerfGrid.SelectedItems[i] as StudPerf;
                        AppConnect.model.StudPerf.Remove(prodObj);
                    }
                    AppConnect.model.SaveChanges();
                }
                else
                {
                    MessageBox.Show("Hет данных!", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            PerfGrid.ItemsSource = AppConnect.model.StudPerf.ToList();
        }

        private void cmbDisc_SelectionChanged(object sender, SelectionChangedEventArgs e)
        { 
            tbSearch.Text = "";          
            if (cmbDisc.SelectedIndex >= 0)
            {
                cmbGroup.SelectedIndex = -1;                

                var cur = AppConnect.model.StudPerf.ToList();
                cur = cur.Where(x => x.Discipline.Наименование.ToString().StartsWith(cmbDisc.SelectedItem.ToString())).ToList();
                PerfGrid.ItemsSource = cur.ToList();
            }
        }
    }
}
