﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PP
{
    /// <summary>
    /// Логика взаимодействия для AddInfPage.xaml
    /// </summary>
    public partial class AddPerfPage : Page
    {
        public StudPerf center = new StudPerf();
        private readonly StudPerf centerfield = new StudPerf();
        public AddPerfPage()
        {
            InitializeComponent();
            cmbGroup.SelectedValuePath = "id";
            cmbGroup.DisplayMemberPath = "Название";
            cmbGroup.ItemsSource = AppConnect.model.Group.ToList();
            cmbDisc.SelectedValuePath = "id";
            cmbDisc.DisplayMemberPath = "Наименование";
            cmbDisc.ItemsSource = AppConnect.model.Discipline.ToList();
            cmbFIO.ItemsSource=AppConnect.model.PersInf.Select(x=>x.ФИО).Distinct().ToList();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            AppFrame.frameMain.GoBack();
        }

        private void btnApply_Click(object sender, RoutedEventArgs e)
        {            
            try
            {                 
                StudPerf servObj = new StudPerf()
                {
                    id = Convert.ToInt32(tbID.Text),
                    Group = cmbGroup.SelectedItem as Group,
                    Учащийся = cmbFIO.SelectedIndex,
                    Discipline=cmbDisc.SelectedItem as Discipline,
                    Оценка = Convert.ToInt32(tbOtz.Text),
                };
                AppConnect.model.StudPerf.Add(servObj);
               

                AppConnect.model.SaveChanges();
                AppFrame.frameMain.GoBack();
            }
            catch (DbEntityValidationException ex)
            {
                MessageBox.Show("Ошибка:" + ex.Message.ToString(), "Критическая ошибка!", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
    }
}
